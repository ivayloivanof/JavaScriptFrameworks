var app = angular.module("BindImageSource", []);

app.controller('BindImage', function ($scope) {
	$scope.imageSource = "http://www.gettyimages.ie/gi-resources/images/Homepage/Category-Creative/UK/UK_Creative_462809583.jpg";
});